package com.cg.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.bean.Account;
import com.cg.bean.Message;
import com.cg.bean.Transaction;
import com.cg.bean.Transfer;
import com.cg.service.AccountOperation;

@RestController
@RequestMapping("/accounts")
public class Controller {
	@Autowired
	private AccountOperation operation;
	
	@PostMapping(value="/new",consumes= {"application/json"},produces= {"application/json"})
	public Object createAccount(@RequestBody Account account) {
		System.out.println(account);
		boolean flag=operation.addAccount(account);
		Message message;
		if(!flag) {
			message=new Message(true,"Account Creation Failed");
			return message;
		}
		message=new Message(false,"Account Created");
		return message;
	}
	@PostMapping(value="/withdraw",consumes= {"application/json"},produces= {"application/json"})
	public Object withdraw(@RequestBody Transaction transaction) {
		System.out.println(transaction);
		boolean flag=operation.withdraw(transaction);
		Message message;
		if(flag) {
			message=new Message(true,"Transaction Sucessfull");
			return message;
		}
		message=new Message(false,"Transaction Unsuccessfull");
		return message;
	}
	@PostMapping(value="/deposit",consumes= {"application/json"},produces= {"application/json"})
	public Object deposit(@RequestBody Transaction transaction) {
		System.out.println(transaction);
		boolean flag=operation.deposit(transaction);
		Message message;
		if(flag) {
			message=new Message(true,"Transaction Sucessfull");
			return message;
		}
		message=new Message(false,"Transaction Unsuccessfull");
		return message;
	}
	@GetMapping(value="/getAll",produces= {"application/json"})
	public Object getAll() {
		List<Account> account=operation.getAll();
		if(account==null) {
			System.out.println("No account exist in the database");
			Message e=new Message(true,"No account exist in the database");
			return e;			
		}
		return account;
	}
	@PostMapping(value="/transfer",consumes= {"application/json"},produces= {"application/json"})
	public Object transfer(@RequestBody Transfer transfer) {
		System.out.println(transfer);
		boolean flag=operation.transfer(transfer);
		Message message;
		if(flag) {
			message=new Message(true,"Transaction Sucessfull");
			return message;
		}
		message=new Message(false, "Transaction Unsuccessfull,Unsufficient Balance");
		return message;
	}
	@PutMapping(value="/update",consumes= {"application/json"},produces= {"application/json"})
	public Object update(@RequestBody Account account) {
		System.out.println(account);
		boolean flag=operation.updateAccount(account,account.getMobile());
		Message message;
		if(flag) {
			message=new Message(true,"Account Updated");
			return message;
		}
		message=new Message(false,"Account Updation Failed");
		return message;
	}
	@DeleteMapping(value="/delete/{mob}",produces= {"application/json"})
	public Object delete(@PathVariable Long mob) {
		System.out.println(mob);
		boolean flag=operation.deleteAccount(mob);
		Message message;
		if(flag) {
			message=new Message(false,"Account deleted");
			return message;
		}
		message=new Message(true,"Account does not exist");
		return message;
	}
	@GetMapping(value="/find/{mob}",produces= {"application/json"})
	public Object find(@PathVariable Long mob) {
		System.out.println(mob);
		Account account=operation.findAccount(mob);
		if(account==null) {
			System.out.println("No account associated with the given mobile number exist");
			Message e=new Message(true,"No account associated with the given mobile number exist");
			return e;
		}
		return account;
	}
	
	

}
