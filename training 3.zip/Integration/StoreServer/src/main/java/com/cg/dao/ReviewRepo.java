package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.cg.beans.Review;

public interface ReviewRepo extends JpaRepository<Review, Integer>,CrudRepository<Review, Integer>{
	
}
