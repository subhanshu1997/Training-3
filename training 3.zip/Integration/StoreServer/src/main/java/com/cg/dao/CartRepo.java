package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.beans.Cart;
import com.cg.beans.User1;



public interface CartRepo extends JpaRepository<Cart, Integer>{
	public Cart findByuser(User1 user);
}
