package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.beans.User1;



public interface CustomerRepo extends JpaRepository<User1, Integer>{

	public User1 findByuserId(int userId);

}
