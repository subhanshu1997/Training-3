package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.beans.Discount;


@Repository
public interface DiscountRepo extends JpaRepository<Discount, Integer>{

}
