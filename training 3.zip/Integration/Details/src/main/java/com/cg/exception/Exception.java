package com.cg.exception;

public class Exception extends RuntimeException{
	public Exception(String message) {
		super(message);
	}
	
}
