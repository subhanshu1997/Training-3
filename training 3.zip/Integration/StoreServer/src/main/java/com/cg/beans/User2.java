package com.cg.beans;

public class User2 {
private int userId;

public int getUserId() {
	return userId;
}

public void setUserId(int userId) {
	this.userId = userId;
}
}
