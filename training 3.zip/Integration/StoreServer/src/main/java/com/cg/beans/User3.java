package com.cg.beans;

public class User3 {
private static int productId;
private static int userId;
public static int getProductId() {
	return productId;
}
public void setProductId(int productId) {
	this.productId = productId;
}
public static int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}

}
