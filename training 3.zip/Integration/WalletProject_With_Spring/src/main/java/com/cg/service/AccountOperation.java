package com.cg.service;
import java.util.*;
import com.cg.bean.Account;
import com.cg.bean.Transaction;
import com.cg.bean.Transfer;
public interface AccountOperation {
public boolean withdraw(Transaction transaction);
public boolean deposit(Transaction transaction);
public boolean transfer(Transfer transfer);
public boolean addAccount(Account ob);
public boolean deleteAccount(Long mob);
public Account findAccount(Long mobileno);
public List<Account> getAll();
public boolean updateAccount(Account ob,Long mob);
}
