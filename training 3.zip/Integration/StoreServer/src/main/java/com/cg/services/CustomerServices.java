package com.cg.services;

import java.util.List;

import com.cg.beans.Address;
import com.cg.beans.Cart;
import com.cg.beans.User1;
import com.cg.beans.Product;
import com.cg.exceptions.CustomerNotFoundException;
import com.cg.exceptions.InvalidInputException;
import com.cg.exceptions.ProductUnavailableException;

public interface CustomerServices {


	public boolean addProductToWishlist(int userId,int productId) throws InvalidInputException;

	public boolean removeProductFromWishlist(int userId,int productId) throws InvalidInputException;

	public List<Product> getWishlist(int userId) throws InvalidInputException;


	Cart addProductToNewCart(int userId,int productId, double amount) throws ProductUnavailableException;


}
